package citi.demo.gp;

import java.util.List;


public class StaticGP {
	
	public static <T extends Number> List<T> sort(List<T> list){
		return list;
	}
	
	public static void runMutipleThread(List<? extends Thread> threads){
	}

}
