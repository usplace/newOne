package citi.demo.gp;

import java.util.ArrayList;
import java.util.List;

public class TypeErasing {

	public static void main(String[] args){
		List<String> list1=new ArrayList<String>(); // ArrayList
		List<Integer> list2=new ArrayList<Integer>(); //ArrayList
		
		System.out.println("list1 is "+list1.getClass());
		System.out.println("list2 is "+list2.getClass());
	}
	
}
