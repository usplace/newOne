package citi.demo.ser;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.List;

public class DemoObject implements Serializable {


	private static final long serialVersionUID = -5290287354650963138L;
	
	public static int testValue=100;
	
	private transient String nonSerValue;
	
	private String name;
	
	private int age;
	
	private String soeid;
	
	private String ssoPassword;
	
	private long onboardTime;
	
	private List<String> phones;

	public String getNonSerValue() {
		return nonSerValue;
	}

	public void setNonSerValue(String nonSerValue) {
		this.nonSerValue = nonSerValue;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getSoeid() {
		return soeid;
	}

	public void setSoeid(String soeid) {
		this.soeid = soeid;
	}

	public long getOnboardTime() {
		return onboardTime;
	}

	public void setOnboardTime(long onboardTime) {
		this.onboardTime = onboardTime;
	}

	public List<String> getPhones() {
		return phones;
	}

	public void setPhones(List<String> phones) {
		this.phones = phones;
	}

	public String getSsoPassword() {
		return ssoPassword;
	}

	public void setSsoPassword(String ssoPassword) {
		this.ssoPassword = ssoPassword;
	}
	
	public String toString(){
		StringBuilder builder=new StringBuilder();
		builder.append("name:").append(name).append("   ");
		builder.append("soeid:").append(soeid).append("   ");
		builder.append("age:").append(age).append("   ");
		builder.append("onboard time:").append(onboardTime).append("   ");
		builder.append("phone:").append(phones).append("   ");
		builder.append("sso password:").append(ssoPassword).append("   ");
		builder.append("non-ser value(transient):").append(nonSerValue).append("   ");
		builder.append("test value(static):").append(testValue);
		return builder.toString();
	}
	
	
	private void writeObject(ObjectOutputStream oout) throws IOException{
		String originalPwd=this.ssoPassword;
		String encryptedPwd=encryptPwd(originalPwd);
		
		this.ssoPassword=null;
		oout.defaultWriteObject();
		oout.writeObject(encryptedPwd);
		
		this.ssoPassword=originalPwd; // restore
	}
	
	private void readObject(ObjectInputStream oin) throws IOException, ClassNotFoundException{
		oin.defaultReadObject();
		
		String encryptedPwd=(String)oin.readObject();  // read last object
		String plainedPwd=decryptPwd(encryptedPwd);
		this.ssoPassword=plainedPwd;
	}
	
	private static String encryptPwd(String pwd){
		return pwd+"@@@";
	}
	
	private static String decryptPwd(String pwd){
		return pwd.substring(0, pwd.length()-3);
	}
	
	

}
