package citi.demo.ser;

import java.beans.XMLDecoder;
import java.beans.XMLEncoder;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * refer: http://developer.51cto.com/art/201202/317181.htm
 * <p>http://www.ibm.com/developerworks/cn/java/j-lo-serial/
 * 
 * <p>homework: RMI, JMS, singleton
 *
 */
public class SerDemo1 {
	
	public static void main(String[] args) throws Exception{
		serialize2Bin();
		serialize2XML();
		
		deserFromBin();
		deserFromXML();
		
		testSerList();
	}
	
	private static void serialize2Bin() throws Exception{
		File file=new File("demo.bin");
		ObjectOutputStream oout=new ObjectOutputStream(new FileOutputStream(file));
		DemoObject demo=newMockedDemoObject();
		demo.testValue=1000;
		oout.writeObject(demo); //decompile to show details
		demo.testValue=2000;    //verify the static variable
		oout.close();
	}
	
	private static void serialize2XML() throws Exception{
		//XMLEncoder
		File file=new File("demo.xml");
		ObjectOutputStream oout=new ObjectOutputStream(new FileOutputStream(file));
		XMLEncoder e = new XMLEncoder(oout);
		DemoObject demo=newMockedDemoObject();
		e.writeObject(demo);
		e.close();
	}
	
	private static void deserFromBin() throws Exception{
		ObjectInputStream oin=new ObjectInputStream(new FileInputStream("demo.bin"));
		DemoObject demo=(DemoObject)oin.readObject();
		oin.close();
		System.out.println(demo);
	} 
	
	private static void deserFromXML() throws Exception{
		ObjectInputStream oin=new ObjectInputStream(new FileInputStream("demo.xml"));
		XMLDecoder e = new XMLDecoder(oin);
		DemoObject demo=(DemoObject)e.readObject();
		e.close();
		System.out.println(demo);
	} 
	
	private static void encryptPwd() throws Exception{
		// question: XML, how to customize readObject/writeObject with XML serialization?
	}
	
	
	private static void testExternalizable(){
		// homework
		// writeExternal
		// readExternal
	}
	
	private static void testSerList() throws Exception{
		// homework
		List<DemoObject> demos=new ArrayList<DemoObject>();
		File file=new File("demo_list.bin");
		ObjectOutputStream oout=new ObjectOutputStream(new FileOutputStream(file));
		oout.writeObject(demos); 
		oout.close();
	}
	
	private static void testSingleton(){
		// homework
	}
	
	private static DemoObject newMockedDemoObject(){
		DemoObject demo=new DemoObject();
		demo.setNonSerValue("hello world");
		demo.setSsoPassword("pwd123");
		
		List<String> phones=new ArrayList<String>();
		phones.add("+862128961234");
		phones.add("+8613912345678");
		demo.setPhones(phones);
		
		return demo;
	}
	

}
