package citi.demo.jmx;

public interface ConfigAlertParamMBean {

	public String getName();
	
	public void setName(String name);
	
	public boolean changeAlertThreshold(int thresholdPercent);

	public void stopAndExit();
	
}
