package citi.demo.jmx;

import java.lang.management.ManagementFactory;
import java.util.Random;

import javax.management.MBeanServer;
import javax.management.ObjectName;

public class StartJMXServer {
	
	// JVM parameters:
	// -Dcom.sun.management.jmxremote.port=10000 -Dcom.sun.management.jmxremote.authenticate=false -Dcom.sun.management.jmxremote.ssl=false
	//

	public static void main(String[] args){
		
		ConfigAlertParam bean1=new ConfigAlertParam();
		bean1.setName("disk usage threshold");
		
		MBeanServer mbeanServer=ManagementFactory.getPlatformMBeanServer();
		try{
			mbeanServer.registerMBean(bean1,ObjectName.getInstance("config:type=AlertParam"));
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		while(!bean1.isStopped()){
			int currentDiskUsage=new Random().nextInt(90);
			boolean exceeded = bean1.isExceedThreshold(currentDiskUsage);
			if(exceeded){
				System.out.println("disk usage has exceeded threshold:"+currentDiskUsage);
			}
			
			try{
				Thread.sleep(2000L);
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}	
		
		System.out.println("jmx sever is stopped");
	}

}
