package citi.demo.jmx;

import java.util.HashMap;
import java.util.Map;

import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.management.remote.JMXConnector;
import javax.management.remote.JMXConnectorFactory;
import javax.management.remote.JMXServiceURL;
import javax.management.remote.rmi.RMIConnectorServer;
import javax.naming.Context;

public class JMXClient1 {

	public static void main(String[] args) throws Exception {
		
		Map<String, Object> jmxEnv=new HashMap<String, Object>();
		jmxEnv.put(Context.INITIAL_CONTEXT_FACTORY,"com.sun.jndi.rmi.registry.RegistryContextFactory");
		jmxEnv.put(RMIConnectorServer.JNDI_REBIND_ATTRIBUTE,"true");
		
		JMXServiceURL jmxServerUrl=new JMXServiceURL("service:jmx:rmi:///jndi/rmi://localhost:10000/jmxrmi");
		JMXConnector connector=JMXConnectorFactory.connect(jmxServerUrl,jmxEnv);
		MBeanServerConnection conn = connector.getMBeanServerConnection();
		
		Object result=conn.invoke(new ObjectName("config:type=AlertParam"), "changeAlertThreshold", new Object[]{ 50 }, new String[]{"int"});
		System.out.println(result);
		
		// homework  attribute (tips: conn.getAttribute)
		
		// get memory usage of the server process  (tips: java internal mbean)
		
	}
	
	
	
}
