package citi.demo.jmx;

public class ConfigAlertParam implements ConfigAlertParamMBean{

	private String name; //this is an attribute
	
	private volatile int diskThreshold=80;
	
	private volatile boolean stop=false;
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public void setName(String name) {
		this.name=name;
	}

	@Override
	public boolean changeAlertThreshold(int thresholdPercent) {
		this.diskThreshold=thresholdPercent;
		
		System.out.println("====set disk usage threshold:" + thresholdPercent );
		return true;
	}
	
	public boolean isExceedThreshold(int currentDiskUsage){
		return currentDiskUsage>=diskThreshold;
	}

	@Override
	public void stopAndExit() {
		stop=true;
	}
	
	public boolean isStopped(){
		return stop;
	}
	

}
