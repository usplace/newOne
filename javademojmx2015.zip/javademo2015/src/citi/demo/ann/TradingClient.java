package citi.demo.ann;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;

public class TradingClient {

	public static void main(String[] args){
		
		InvocationHandler LogAdvice = new AopLogAdvice();
		TradingService tradingService = (TradingService) Proxy.newProxyInstance(
				TradingService.class.getClassLoader(), new Class[] { TradingService.class }, LogAdvice);
		
		
		tradingService.login("soeid","pwd");
		
		
		double price = tradingService.getPrice("Bond-US-Treasury");
		System.out.println("price:"+price);
		
		tradingService.buyIn();
		
		
	}
	
}
