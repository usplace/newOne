/**
 * 
 */
package citi.demo.ann;

import java.net.URL;
import java.util.Enumeration;

/**
 * @author fs42803
 *
 */
public class ClassScanner {
	
	public static void main(String[] args) throws Exception{
		// homework
		ClassLoader loader=ClassScanner.class.getClassLoader();
		Enumeration<URL> resources = loader.getResources("*Service.class");
		System.out.println(resources);
	}

}
