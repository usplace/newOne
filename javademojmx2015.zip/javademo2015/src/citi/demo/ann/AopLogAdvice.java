package citi.demo.ann;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

public class AopLogAdvice implements InvocationHandler{

	private TradingService tradingServiceImpl =new TradingServiceImpl();
	
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		LoggingAnn annotation = method.getAnnotation(LoggingAnn.class);
		if(annotation.addlog()){
			if(args==null)
				System.out.println(method.getName()+", type="+annotation.logtype());
			else
				System.out.println(method.getName()+", type="+annotation.logtype()+",arg[0]="+args[0]);
		}
		return method.invoke(tradingServiceImpl, args);
	}

}
