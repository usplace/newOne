package citi.demo.ann;

public class TradingServiceImpl implements TradingService{

	@Override
	public boolean buyIn() {
		return true;
	}

	@Override
	public void saleOut(String tradeId, double price, String productId) throws Exception {
	}

	@Override
	public double getPrice(String productId) {
		return 100.1d;
	}

	@Override
	public void login(String user, String pwd) {
	}

}
