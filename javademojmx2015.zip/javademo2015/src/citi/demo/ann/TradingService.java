package citi.demo.ann;

public interface TradingService {

	@LoggingAnn(addlog=true,logtype="operation")
	public boolean buyIn();
	
	@LoggingAnn   //use default value
	public void saleOut(String tradeId, double price, String productId) throws Exception;
	
	@LoggingAnn(addlog=false)
	public double getPrice(String productId);
	
	@LoggingAnn(addlog=true,logtype="security")
	public void login(String user, String pwd);
	
}
