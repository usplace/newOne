package test.citi.demo.ann;

import junit.framework.Assert;

import org.junit.Test;

import citi.demo.ann.TradingService;
import citi.demo.ann.TradingServiceImpl;

public class TestTradingService {
	
	@Test
	public void testTradingService(){
		TradingService tradingService=new TradingServiceImpl();
		double bidPrice = tradingService.getPrice("bond");
		Assert.assertEquals(100.1d, bidPrice);
	}

}
