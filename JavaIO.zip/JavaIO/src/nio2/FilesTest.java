package nio2;

import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

public class FilesTest {

	public static void main(String[] args) throws Exception{
		Path path = Paths.get("src/nio2/FilesTest.java");
		Files.copy(path, new FileOutputStream("a.txt"));
		System.out.println(Files.isHidden(path));
		List<String> lines = Files.readAllLines(path,Charset.forName("GBK"));
		System.out.println(lines);
		System.out.println(Files.size(path));
		lines.clear();
		lines.add("a");
		lines.add("b");
		Files.write(Paths.get("a.txt"), lines, Charset.defaultCharset());
	}

}
