package thread.local;

import java.util.Date;

public class Task implements Runnable {
	

	@Override
    public void run() {
        for(int i=0; i<200; i++){
            System.out.println("Thread: " + Thread.currentThread().getName() + " "
            	+ "Formatted Date: " + ThreadSafeFormatter.getDateFormatter().format(new Date()) );
        }       
    }


}
