package thread.pool;

import java.util.Random;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;

public class CalTaskTest {

	public static void main(String[] args) throws Exception{
		int[] arr=new int[3000];
		Random rand = new Random();
		int total=0;
		//��arr��ֵ
		for(int i=0,len=arr.length;i<len;i++){
			int tmp=rand.nextInt(3000);
			total+=(arr[i]=tmp);
		}
		System.out.println("total="+total);
		
		ForkJoinPool pool = new ForkJoinPool(6);
//		ForkJoinPool pool = new ForkJoinPool();
		Future<Integer> future = pool.submit(new CalTask(arr,0, arr.length));
		System.out.println("���м�����ĺ�:"+future.get());
		pool.shutdown();
	}

}
