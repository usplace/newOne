package thread.pool;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.TimeUnit;

public class PrintTaskTest {

	public static void main(String[] args) throws Exception{
		ForkJoinPool pool = new ForkJoinPool(6);
//		ForkJoinPool pool = new ForkJoinPool();
		pool.submit(new PrintTask(0, 3000));
		pool.awaitTermination(2, TimeUnit.SECONDS);
		pool.shutdown();
	}

}
