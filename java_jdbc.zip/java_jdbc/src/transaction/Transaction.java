package transaction;

import java.sql.Connection;
import java.sql.PreparedStatement;

import conn.MyConnManager;

public class Transaction {
	
	public static void main(String[] args) throws Exception{
		Connection conn = MyConnManager.getConnection();
		conn.setAutoCommit(false);
		try{
			insert(conn, "fs1111", "test1", "I");
			insert(conn, "fs222", "test2"+System.currentTimeMillis()+1000,"II");
			
			conn.commit();
			System.out.println("transaction committed");
		}catch(Exception ex){
			System.out.println("will rollback transaction due to "+ex.getMessage());
			conn.rollback();
		}
		
		conn.close();
	}
	
	private static void insert(Connection conn, String soeid, String name, String unit) throws Exception{
		PreparedStatement statement = conn.prepareStatement("insert into A_INTERN_TEST(soeid, name, unit, score,onboardtime) values(?,?,?,?,?)");
		statement.setString(1, soeid);
		statement.setString(2, name);
		statement.setString(3, unit);
		statement.setInt(4, 100);
		statement.setLong(5, System.currentTimeMillis());
		statement .executeUpdate();
		statement.close();
		
		//if(unit.equals("II")){
		//	throw new RuntimeException("test");
		//}
	}
}
