package spring;

import java.util.HashSet;
import java.util.Set;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class StartSpring {
	
	public static void main(String[] args) throws Exception{
		ApplicationContext ctx=new ClassPathXmlApplicationContext(
                new String[]{"classpath:spring/applicationContext.xml"});
		
		UserDaoImpl userDao = (UserDaoImpl)ctx.getBean("userDao");
		
		
		User user=new User();
		user.setUserName("test");
		user.setPassword("password");
		Set<String> roles=new HashSet<String>();
		roles.add("admin");
		roles.add("viewer");
		user.setRoles(roles);
		
		userDao.insert(user);
		
		System.out.println(userDao.getAll());
		
		user.setPassword("new Password");
		userDao.update(user);
		System.out.println(userDao.getAll());
		
	}

}
