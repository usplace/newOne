package spring;

import java.sql.Types;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class UserDaoImpl{

	private JdbcTemplate jdbcTemplate;
	
	private UserMapper userMapper=new UserMapper();
	
	public User getByKey(String userName) {
		List objs = jdbcTemplate.query("select * from A_INTERN_USER where userName=?", new Object[]{userName}, new int[]{Types.VARCHAR}, this.userMapper);
		if(objs==null || objs.size()==0)
			return null;
		return (User)objs.get(0);
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public void insert(User user) {
		jdbcTemplate.update("insert into A_INTERN_USER(username, password, role) values(?,?,?)", 
				new Object[]{ user.getUserName(), user.getPassword(), Utils.set2String(user.getRoles(),",") }, 
				new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR});
	}
	
	public void update(User user) {
		jdbcTemplate.update("update A_INTERN_USER set password=?, role=? where username=?", 
				new Object[]{ user.getPassword(), Utils.set2String(user.getRoles(),","),  user.getUserName() },
				new int[]{Types.VARCHAR, Types.VARCHAR, Types.VARCHAR});
	}
	
	public List<User> getAll(){
		List objs = jdbcTemplate.query("select * from A_INTERN_USER", this.userMapper);
		return objs;
	}
	
	public void delete(String userName) {
		jdbcTemplate.update("delete from A_INTERN_USER where username=?", new Object[]{userName}, new int[]{Types.VARCHAR} );
	}


	
}