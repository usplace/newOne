package conn;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyConnManager {
	
	public final static String DRIVER_NAME="oracle.jdbc.driver.OracleDriver";
	public final static String DB_URL="jdbc:oracle:thin:@fxdspmwdb1d.nam.nsroot.net:2523:DSPDBD5";
	public final static String DB_USER="DSP_DBO";
	public final static String DB_PASSWORD="dsp24dbo";
	
	public static Connection getConnection(){
		Connection con = null;
		try {
			Class.forName(DRIVER_NAME);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}
	
	

}
