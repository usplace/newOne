package update;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;

import conn.MyConnManager;

public class InsertUpdate {
	
	public static void main(String[] args) throws Exception{
		insert();
		update();
		batchUpdate();
		delete();
	}
	
	private static void insert() throws Exception{
		Connection conn = MyConnManager.getConnection();
		PreparedStatement statement = conn.prepareStatement("insert into A_INTERN_TEST(soeid, name, unit, score,onboardtime) values(?,?,?,?,?)");
		statement.setString(1, "ts12345");
		statement.setString(2, "test");
		statement.setString(3, "I");
		statement.setInt(4, 100);
		statement.setLong(5, System.currentTimeMillis());
		statement .executeUpdate();
		
		statement.close();
		conn.close();
	}
	
	private static void update() throws Exception{
		Connection conn = MyConnManager.getConnection();
		PreparedStatement statement = conn.prepareStatement("update A_INTERN_TEST set onboardtime=? where unit=?");
		statement.setLong(1, System.currentTimeMillis());
		statement.setString(2, "I");
		statement .executeUpdate();
		
		statement.close();
		conn.close();
	}
	
	private static void batchUpdate() throws Exception{
		Connection conn = MyConnManager.getConnection();
		conn.setAutoCommit(false);
		Statement statement =conn.createStatement();
		for(int i=0; i<100; i++){
			statement.addBatch("insert into A_INTERN_TEST(soeid, name, unit, score,onboardtime) values('ts12345','test','I',100,"+System.currentTimeMillis()+")");
		}
		statement.executeBatch();
		conn.commit();
		
		statement.close();
		conn.close();
	}

	
	private static void delete() throws Exception{
		Connection conn = MyConnManager.getConnection();
		PreparedStatement statement = conn.prepareStatement("delete A_INTERN_TEST where unit=?");
		statement.setString(1, "I");
		statement.executeUpdate();
		
		statement.close();
		conn.close();
		
	}
	
	
	

}
