package dbcp;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import conn.MyConnManager;

public class QueryWithPool {
	
	public static void main(String[] args) throws Exception{
		long t1=System.currentTimeMillis();
		for(int i=0; i<200; i++){
			Connection conn = DataSource.getInstance().getConnection();
			query(conn);
			conn.close();
		}
		long t2=System.currentTimeMillis();
		System.out.println("pool t:"+(t2-t1));
		
		long t3=System.currentTimeMillis();
		for(int i=0; i<200; i++){
			Connection conn = MyConnManager.getConnection();
			query(conn);
			conn.close();
		}
		long t4=System.currentTimeMillis();
		System.out.println("no pool t:"+(t4-t3));
		
			
	}
	
	private static void query(Connection conn) throws Exception{
		PreparedStatement statement = conn.prepareStatement("select soeid, name from A_INTERN_TEST where unit=?");
		statement.setString(1, "VI");
		statement.setFetchSize(1000);
		
		ResultSet rs = statement.executeQuery();
		while(rs.next()){
			System.out.println(rs.getString(1)+","+rs.getString(2));
		}
		rs.close();
	}
	
	
}
