package query;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import conn.MyConnManager;

public class Query {
	
	public static void main(String[] args) throws Exception{
		Connection conn = MyConnManager.getConnection();
		
		query(conn);
		
		callSP(conn);
		
		conn.close();
	}
	
	private static void query(Connection conn) throws Exception{
		PreparedStatement statement = conn.prepareStatement("select soeid, name from A_INTERN_TEST where unit=?");
		statement.setString(1, "VI");
		statement.setFetchSize(1000);
		
		ResultSet rs = statement.executeQuery();
		while(rs.next()){
			System.out.println(rs.getString(1));
		}
		rs.close();
	}
	
	
	private static void callSP(Connection conn) throws Exception{
		// https://docs.oracle.com/cd/E17952_01/connector-j-en/connector-j-usagenotes-statements-callable.html
		CallableStatement callableStatement = conn.prepareCall("{call demoSp(?, ?)}");
		callableStatement.setString(1, "VI");
		callableStatement.registerOutParameter(2, OracleTypes.CURSOR);
		callableStatement.execute();
		ResultSet rs =((OracleCallableStatement)callableStatement).getCursor(2);
		while(rs.next()){
			System.out.println("inside sp SOEID:"+rs.getString("SOEID"));
		}
		rs.close();
	}
	
	
	

}
