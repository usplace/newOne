package query;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import conn.MyConnManager;

public class InsertData {

	public static void main(String[] args) throws SQLException {
		Connection conn = MyConnManager.getConnection();
		conn.setAutoCommit(false);
		Statement statement =conn.createStatement();
		
		//String sql = "insert into DATA_SPARK(NAME, DTIME, OPEN, HIGH,LOW,CLOSE,VOLUMN,SPLIT,EARNINGS,DIVIDENDS) values('a',TO_DATE('2013-01-02 09:11:00','yyyy-mm-dd hh24:mi:ss'), '100', '211','200','111','1','1','1','1')";
		String sql = "insert into DATA_SPARK values('a',TO_DATE('2013-01-02 09:11:00','yyyy-mm-dd hh24:mi:ss'), '100', '211','200','111','1','1','1','1')";
		for(int i=0; i<100; i++){
			statement.addBatch(sql);
		}
		statement.executeBatch();
		conn.commit();
		
		statement.close();
		conn.close();
	}

}
