package query;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;

import conn.MyConnManager;

public class MetaDataQuery {

	public static void main(String[] args) throws Exception{
		Connection conn = MyConnManager.getConnection();
		metadata(conn);
		conn.close();
	}
	
	private static void metadata(Connection conn) throws Exception{
		DatabaseMetaData metaData = conn.getMetaData();
		String url = metaData.getURL();
		System.out.println("url: "+url);
		
		ResultSet rs = metaData.getTables(null, "DSP_DBO", "%", new String[]{"TABLE"});
		while (rs.next()){
			String tableName = rs.getString("TABLE_NAME");
			System.out.println("table:"+tableName);
		}
		
	}
	
	
}
