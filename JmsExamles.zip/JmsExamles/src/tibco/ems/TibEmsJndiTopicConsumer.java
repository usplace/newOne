package tibco.ems;

import java.util.Hashtable;

import javax.jms.BytesMessage;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicSubscriber;
import javax.naming.Context;
import javax.naming.InitialContext;

public class TibEmsJndiTopicConsumer {

	public static void main(String[] args) throws Exception{
		String providerContextFactory = "com.tibco.tibjms.naming.TibjmsInitialContextFactory";
		String providerURL = "tibjmsnaming://fisimpcal4d.nam.nsroot.net:7078";
		String userName = "admin";
		String password = "admin";
        
        Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, providerContextFactory);
		env.put(Context.PROVIDER_URL, providerURL);
		env.put(Context.SECURITY_PRINCIPAL, userName);
		env.put(Context.SECURITY_CREDENTIALS, password);
		
		InitialContext jndiContext = new InitialContext(env);
		Topic topic = (Topic) jndiContext.lookup("topic.jw18233");
		TopicConnectionFactory topicFactory = (TopicConnectionFactory) jndiContext
				.lookup("TopicConnectionFactory");
		TopicConnection topicConn = topicFactory.createTopicConnection();
		final Session session = topicConn.createSession(false,
				javax.jms.Session.AUTO_ACKNOWLEDGE);
         
		session.createConsumer(topic);
		TopicSubscriber ts = (TopicSubscriber)session.createConsumer(topic);
		ts.setMessageListener(new MessageListener(){
			@Override
			public void onMessage(Message msg) {
				if(msg instanceof StreamMessage){
					System.out.println("StreamMessage:"+msg);
			    }else if (msg instanceof ObjectMessage){
					System.out.println("ObjectMessage:"+msg);			    	
			    }else if (msg instanceof TextMessage){
					System.out.println("TextMessage:"+msg);
			    }else if (msg instanceof MapMessage){
					System.out.println("MapMessage:"+msg);
			    }else if (msg instanceof BytesMessage){
					System.out.println("BytesMessage:"+msg);
			    }
			
		
		}});
		topicConn.start();
	}

}
