package tibco.ems;

import java.io.Serializable;

public class Obj implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6889195863514543155L;

	private String name;
	private String passwd;
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getPasswd() {
		return passwd;
	}
}

