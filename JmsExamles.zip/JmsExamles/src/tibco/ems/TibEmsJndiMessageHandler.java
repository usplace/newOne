package tibco.ems;

import java.util.Hashtable;

import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

public class TibEmsJndiMessageHandler {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String destinationName = "topic.hz70318";
		String connectionFactoryType = "TopicConnectionFactory";
	//	String connectinoFactoryType1 ="QueueConnectionFactory";
		handleMessage(destinationName, connectionFactoryType, "produce");
		handleMessage(destinationName, connectionFactoryType, "consume");

		destinationName = "queue.hz70318";
		connectionFactoryType = "QueueConnectionFactory";
		handleMessage(destinationName, connectionFactoryType, "produce");
		handleMessage(destinationName, connectionFactoryType, "consume");
	}

	private static void handleMessage(String destinationName,
			String connectionFactoryType, String type) throws NamingException,
			JMSException {
		String providerContextFactory = "com.tibco.tibjms.naming.TibjmsInitialContextFactory";
		String providerURL = "tibjmsnaming://fisimpcal4d.nam.nsroot.net:7077";
		String userName = "admin";
		String password = "admin";
		// Alt+Shift+R

		Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, providerContextFactory);
		env.put(Context.PROVIDER_URL, providerURL);
		env.put(Context.SECURITY_PRINCIPAL, userName);
		env.put(Context.SECURITY_CREDENTIALS, password);

		InitialContext jndiContext = new InitialContext(env);
		ConnectionFactory connectionFactory = (ConnectionFactory) jndiContext
				.lookup(connectionFactoryType);
		Connection connection = connectionFactory.createConnection();
		connection.start();
		final Session session = connection.createSession(false,
				javax.jms.Session.AUTO_ACKNOWLEDGE);

		// Alt+Shift+L
		Destination destination = (Destination) jndiContext
				.lookup(destinationName);

		if (type.equals("produce")) {
			MessageProducer mp = session.createProducer(destination);
			TextMessage message = session.createTextMessage();
			message.setText("message.hz70318");
			mp.send(message);

			connection.close();
		} else {
			MessageConsumer messageConsumer = session
					.createConsumer(destination);
			messageConsumer.setMessageListener(new MessageListener() {

				@Override
				public void onMessage(Message msg) {
					System.out.println(msg);
					try {
						msg.acknowledge();
					} catch (JMSException e) {
						e.printStackTrace();
					}
				}
			});
		}
	}

}
