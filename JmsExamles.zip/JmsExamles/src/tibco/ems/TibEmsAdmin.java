package tibco.ems;

/* 
 * Copyright 2001-2006 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 * 
 * $Id: tibjmsRoute.java 21731 2006-05-01 21:41:34Z $
 * 
 */

/*
 * Example of how to use TIBCO Enterprise Message Service Administration API
 * to create and administer routes.
 *
 * This sample does the following:
 * 1) Creates a RouteInfo with parameters:
 *
 *    name = value specified by "-routeName" argument.
 *           Default is "E4JMS-SERVER-RT".
 *    url  = value specified by "-routeURL" argument.
 *           Default is "tcp://localhost:7223".
 *
 * 2) Changes the route URL to "tcp://localhost:7224" and updates the route.
 *
 * 3) Gets all of the routes from the server and prints them out.
 *
 * 4) Destroys the route created in this sample.
 *
 *
 *
 * Usage:  java tibjmsRoute  [options]
 *
 *    where options are:
 *
 *      -server     Server URL.
 *                  If not specified this sample assumes a
 *                  serverUrl of null
 *      -user       Admin user name. Default is "admin".
 *      -password   Admin password. Default is null.
 *      -routeName  The server name of the TIBCO EMS
 *                  server that will participate in routing.
 *                  Default is "E4JMS-SERVER-RT".
 *      -routeURL   The server URL of the TIBCO EMS
 *                  server that will participate in routing.
 *                  Default is "tcp://localhost:7223".
 *
 */

import com.tibco.tibjms.admin.QueueInfo;
import com.tibco.tibjms.admin.TibjmsAdmin;
import com.tibco.tibjms.admin.TibjmsAdminException;
import com.tibco.tibjms.admin.TopicInfo;

public class TibEmsAdmin
{

    public static void main(String args[]) throws TibjmsAdminException
    {
    	String      serverUrl       = "tcp://fisimpcal4d.nam.nsroot.net:7077";
        String      username        = "admin";
        String      password        = "admin";

		//Create the admin connection to the TIBCO EMS server
        TibjmsAdmin admin = new TibjmsAdmin(serverUrl,username,password);
        TopicInfo topic = new TopicInfo("topic.hz70318");
        QueueInfo queue = new QueueInfo("queue.hz70318");
        admin.createTopic(topic);
        admin.createQueue(queue);
    }


}


