package tibco.ems;

import java.util.Hashtable;

import javax.jms.BytesMessage;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.Session;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;

public class TibEmsJndiQueueConsumer {

	public static void main(String[] args) throws Exception{
		String providerContextFactory = "com.tibco.tibjms.naming.TibjmsInitialContextFactory";
		String providerURL = "tibjmsnaming://fisimpcal4d.nam.nsroot.net:7077";
		String userName = "admin";
		String password = "admin";
        
        Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, providerContextFactory);
		env.put(Context.PROVIDER_URL, providerURL);
		env.put(Context.SECURITY_PRINCIPAL, userName);
		env.put(Context.SECURITY_CREDENTIALS, password);
		
		InitialContext jndiContext = new InitialContext(env);
		Queue queue = (Queue) jndiContext.lookup("queue.hz70318");
		QueueConnectionFactory queueFactory = (QueueConnectionFactory) jndiContext
				.lookup("QueueConnectionFactory");
		QueueConnection queueConn = queueFactory.createQueueConnection();
		final Session session = queueConn.createSession(false,
				javax.jms.Session.AUTO_ACKNOWLEDGE);
		QueueReceiver qr = (QueueReceiver)session.createConsumer(queue);
		qr.setMessageListener(new MessageListener(){
         
			@Override
			public void onMessage(Message msg) {//TODO
				if(msg instanceof StreamMessage){
					System.out.println("StreamMessage:"+msg);
			    }else if (msg instanceof ObjectMessage){
					System.out.println("ObjectMessage:"+msg);			    	
			    }else if (msg instanceof TextMessage){
					System.out.println("TextMessage:"+msg);
			    }else if (msg instanceof MapMessage){
					System.out.println("MapMessage:"+msg);
			    }else if (msg instanceof BytesMessage){
					System.out.println("BytesMessage:"+msg);
			    }
			
		
		}});
		queueConn.start();
	}

}
