package tibco.ems;

import java.util.Hashtable;

import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.Session;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;

import com.tibco.tibjms.TibjmsQueueConnectionFactory;

public class TibEmsQueueConsumer {

	public static void main(String[] args) throws Exception{
		String providerURL = "tcp://fisimpcal4d.nam.nsroot.net:7077";
		String userName = "admin";
		String password = "admin";
        
		QueueConnectionFactory queueFactory = new TibjmsQueueConnectionFactory(providerURL);
		QueueConnection queueConn = queueFactory.createQueueConnection(userName,password);
		final Session session = queueConn.createSession(false,
				javax.jms.Session.AUTO_ACKNOWLEDGE);
		Queue queue = (Queue) session.createQueue("queue.hz70318");
		QueueReceiver qr = (QueueReceiver)session.createConsumer(queue);
		qr.setMessageListener(new MessageListener(){

			@Override
			public void onMessage(Message msg) {
				// TODO Auto-generated method stub
				System.out.println(msg);
			}});
		queueConn.start();
	}

}
