package tibco.ems;

import java.util.Hashtable;

import javax.jms.BytesMessage;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.Session;
import javax.jms.StreamMessage;
import javax.jms.TextMessage;
import javax.jms.TopicConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;

public class TibEmsJndiQueueProducer {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		String providerContextFactory = "com.tibco.tibjms.naming.TibjmsInitialContextFactory";
		String providerURL = "tibjmsnaming://fisimpcal4d.nam.nsroot.net:7077";
		String userName = "admin";
		String password = "admin";
        
        Hashtable<String, String> env = new Hashtable<String, String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY, providerContextFactory);
		env.put(Context.PROVIDER_URL, providerURL);
		env.put(Context.SECURITY_PRINCIPAL, userName);
		env.put(Context.SECURITY_CREDENTIALS, password);
		
		InitialContext jndiContext = new InitialContext(env);
		Queue queue = (Queue) jndiContext.lookup("queue.hz70318");
		QueueConnectionFactory queueFactory = (QueueConnectionFactory) jndiContext
				.lookup("QueueConnectionFactory");
		QueueConnection queueConn = queueFactory.createQueueConnection();
		queueConn.start();
		final Session session = queueConn.createSession(false,
				javax.jms.Session.AUTO_ACKNOWLEDGE);
		MessageProducer mp = session.createProducer(queue);
		TextMessage message = session.createTextMessage();
		message.setText("message.hz70318");
		mp.send(message);
		
		ObjectMessage objmessage = session.createObjectMessage();
		Obj obj = new Obj();
		obj.setName("www");
		obj.setPasswd("111");
		objmessage.setObject(obj);
		mp.send(objmessage);
		
		StreamMessage streamMessage = session.createStreamMessage();
		byte[] bytes = new String("streamMessage").getBytes();
		streamMessage.writeBytes(bytes);
		mp.send(streamMessage);
		
	    MapMessage  mapMessage = session.createMapMessage();
	    mapMessage.setString("key", "value");
	    mp.send(mapMessage);
	    
	    BytesMessage byteMessage = session.createBytesMessage();
	    byte byte1 = 10;
	    byteMessage.writeByte(byte1);;
		mp.send(byteMessage);
		
		queueConn.close();
	}

}
